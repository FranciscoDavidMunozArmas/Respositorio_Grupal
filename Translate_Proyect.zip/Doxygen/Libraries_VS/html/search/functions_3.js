var searchData=
[
  ['speech_5fsynthesizer_16',['Speech_Synthesizer',['../class_speech___synthesizer.html#a48f598873c0df8ef70df62fd0b3bdc54',1,'Speech_Synthesizer']]]
];
