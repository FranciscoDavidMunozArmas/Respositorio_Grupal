var searchData=
[
  ['createpool_13',['createPool',['../class_connection.html#a8728953c952b5a67bc7449f2dee8316c',1,'Connection']]]
];
