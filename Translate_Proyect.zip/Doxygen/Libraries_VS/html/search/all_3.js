var searchData=
[
  ['speech_5fsynthesizer_6',['Speech_Synthesizer',['../class_speech___synthesizer.html',1,'Speech_Synthesizer'],['../class_speech___synthesizer.html#a48f598873c0df8ef70df62fd0b3bdc54',1,'Speech_Synthesizer::Speech_Synthesizer()']]]
];
