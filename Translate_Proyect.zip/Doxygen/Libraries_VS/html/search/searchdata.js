var indexSectionsWithContent =
{
  0: "_cgs~",
  1: "cs",
  2: "_cgs~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

