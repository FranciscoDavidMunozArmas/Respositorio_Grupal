var searchData=
[
  ['get_5fclient_5ffrom_5fpool_14',['get_client_from_pool',['../class_connection.html#aae061bd958b075b32898d8aedabe49e6',1,'Connection']]],
  ['get_5finstance_15',['get_instance',['../class_connection.html#a46e3661d7154b8c969dc1aa5e19fc90c',1,'Connection']]]
];
