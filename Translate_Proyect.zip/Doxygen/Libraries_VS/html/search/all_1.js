var searchData=
[
  ['connection_2',['Connection',['../class_connection.html',1,'']]],
  ['createpool_3',['createPool',['../class_connection.html#a8728953c952b5a67bc7449f2dee8316c',1,'Connection']]]
];
