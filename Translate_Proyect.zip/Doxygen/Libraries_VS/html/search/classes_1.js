var searchData=
[
  ['speech_5fsynthesizer_10',['Speech_Synthesizer',['../class_speech___synthesizer.html',1,'']]]
];
