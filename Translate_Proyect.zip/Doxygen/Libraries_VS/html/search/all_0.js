var searchData=
[
  ['_5fenglish_5fspeech_0',['_english_speech',['../class_speech___synthesizer.html#a85b89c8121014ac0b8b94b3dd7d6c0f9',1,'Speech_Synthesizer']]],
  ['_5fspanish_5fspeech_1',['_spanish_speech',['../class_speech___synthesizer.html#a4d7266dc00fa759f19c9e7b22a60f41b',1,'Speech_Synthesizer']]]
];
