var searchData=
[
  ['_7econnection_17',['~Connection',['../class_connection.html#a2e4352edf667bea83001569e9da8a24d',1,'Connection']]],
  ['_7espeech_5fsynthesizer_18',['~Speech_Synthesizer',['../class_speech___synthesizer.html#a81820b7926566ca8a76d5fe553f04697',1,'Speech_Synthesizer']]]
];
