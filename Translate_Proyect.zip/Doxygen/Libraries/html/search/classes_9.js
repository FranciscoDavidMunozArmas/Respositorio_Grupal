var searchData=
[
  ['qr_5fcode_149',['QR_code',['../class_q_r__code.html',1,'']]]
];
