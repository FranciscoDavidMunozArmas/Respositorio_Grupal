var searchData=
[
  ['next_5ften_238',['next_ten',['../class_i_d__verificator.html#a691a92cb7c7cb308f8eaa73dac1f33c0',1,'ID_verificator']]],
  ['node_5fdouble_239',['Node_Double',['../class_node___double.html#aac7ce6dacbc3cc964eb3963d6f9bd3d2',1,'Node_Double::Node_Double()'],['../class_node___double.html#a3f8368b9905e0b98e6e5dddbad6dc858',1,'Node_Double::Node_Double(T _data, Node_Double *_next, Node_Double *_back)']]]
];
