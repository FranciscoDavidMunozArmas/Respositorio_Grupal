var searchData=
[
  ['end_5fpixel_60',['end_pixel',['../class_pixel.html#ae47eb81502c57dbf8497c811ee237bf8',1,'Pixel']]]
];
