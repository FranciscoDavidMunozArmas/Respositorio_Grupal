var searchData=
[
  ['hide_5fcursor_75',['hide_cursor',['../class_screen.html#a38c4556a4e687da81915768ec64cee17',1,'Screen']]]
];
