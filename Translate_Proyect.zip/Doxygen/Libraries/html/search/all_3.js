var searchData=
[
  ['check_5flast_5fdigit_54',['check_last_digit',['../class_i_d__verificator.html#a5765378f4ed1afc8279a463db823a054',1,'ID_verificator']]],
  ['color_5ftext_55',['color_text',['../class_screen.html#a3fd1fb9c9157fbc0f0338d1b210549cb',1,'Screen']]],
  ['create_5fkey_56',['create_key',['../class_date.html#a033602cfc70c8a4991ccb6979cf3b96e',1,'Date']]],
  ['create_5fmatrix_57',['create_matrix',['../class_matrix.html#ab695f686236250714d1bb69e4d2bade9',1,'Matrix::create_matrix(T **_matrix, int size)'],['../class_matrix.html#aa620ae3865ddd58b13574fb4f0e75828',1,'Matrix::create_matrix(T **_matrix, int width, int height)']]]
];
