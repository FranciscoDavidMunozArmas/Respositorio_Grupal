var searchData=
[
  ['matrix_237',['Matrix',['../class_matrix.html#a2dba13c45127354c9f75ef576f49269b',1,'Matrix']]]
];
