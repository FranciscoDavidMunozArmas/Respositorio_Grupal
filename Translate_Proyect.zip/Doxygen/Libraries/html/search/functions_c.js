var searchData=
[
  ['options_240',['options',['../class_menu.html#abb792447157d29374c8632454ac4d20e',1,'Menu::options(T *option, int index)'],['../class_menu.html#a98bac65a66d393c1d0e27a378b5af6a0',1,'Menu::options(T *option, int index, int color)'],['../class_menu.html#aa02b274bcc8198813b8ae77ec31cd4e0',1,'Menu::options(char *message, T *option, int index)'],['../class_menu.html#a21b30ad8bf38e11081ab8857afe3b712',1,'Menu::options(char *message, T *option, int index, int color)']]]
];
