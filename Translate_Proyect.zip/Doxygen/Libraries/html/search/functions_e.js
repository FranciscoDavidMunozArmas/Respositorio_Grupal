var searchData=
[
  ['ruc_5fverify_248',['RUC_verify',['../class_r_u_c__verificator.html#a4e4615c7c36ca24b505ecac316acc19d',1,'RUC_verificator']]]
];
