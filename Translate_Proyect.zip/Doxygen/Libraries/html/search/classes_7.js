var searchData=
[
  ['node_5fdouble_144',['Node_Double',['../class_node___double.html',1,'']]]
];
