var searchData=
[
  ['qr_5fcode_103',['QR_code',['../class_q_r__code.html',1,'']]]
];
