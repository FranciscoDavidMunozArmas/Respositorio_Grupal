var searchData=
[
  ['controller_5finsert_5ftext_35',['Controller_Insert_text',['../class_controller___insert__text.html#a311d8819a76adfcd180dc3e9f3930251',1,'Controller_Insert_text']]]
];
