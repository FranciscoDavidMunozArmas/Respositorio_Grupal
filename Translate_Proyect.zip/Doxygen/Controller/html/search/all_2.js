var searchData=
[
  ['init_14',['init',['../class_controller___parent.html#a2aa662c729134650590ec12d3bc228b4',1,'Controller_Parent']]]
];
