var searchData=
[
  ['_7econtroller_5fadd_5fword_37',['~Controller_Add_Word',['../class_controller___add___word.html#aed6d146cf05b87c03930dbe7b1e076e3',1,'Controller_Add_Word']]],
  ['_7econtroller_5fdelete_38',['~Controller_Delete',['../class_controller___delete.html#ab0a7002b9f63a5ed7b2ed9254c521f3b',1,'Controller_Delete']]],
  ['_7econtroller_5fedit_39',['~Controller_Edit',['../class_controller___edit.html#ae78c545e479fe4dcbb8f75e530e9b72e',1,'Controller_Edit']]],
  ['_7econtroller_5finsert_5ftext_40',['~Controller_Insert_text',['../class_controller___insert__text.html#a62e5f091d71d6a2364b0f3b1b74f731a',1,'Controller_Insert_text']]],
  ['_7econtroller_5foperation_41',['~Controller_Operation',['../class_controller___operation.html#a424566ea009fad2fde930c4cdc94d284',1,'Controller_Operation']]],
  ['_7econtroller_5ftranslator_42',['~Controller_Translator',['../class_controller___translator.html#a706f7128dda03cc7d83916a4e244a349',1,'Controller_Translator']]]
];
