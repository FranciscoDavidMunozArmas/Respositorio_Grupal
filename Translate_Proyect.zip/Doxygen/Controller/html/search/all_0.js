var searchData=
[
  ['_5fbackup_0',['_backup',['../class_controller___restore.html#ade99bad44af437c8e42087fd819da35d',1,'Controller_Restore']]],
  ['_5fget_5ftext_1',['_get_text',['../class_controller___insert__text.html#a1a377dac94fbb82f405ef55dd038352b',1,'Controller_Insert_text']]],
  ['_5frestore_2',['_restore',['../class_controller___restore.html#a22fc21b160138bd5e291810e54e9244d',1,'Controller_Restore']]],
  ['_5fset_5fdata_3',['_set_data',['../class_controller___delete.html#ac1c4e15af43b45585707212f6b124fcf',1,'Controller_Delete::_set_data()'],['../class_controller___edit.html#ac5b7e0018209725212c17817632865a6',1,'Controller_Edit::_set_data()']]]
];
