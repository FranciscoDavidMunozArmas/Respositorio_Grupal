var searchData=
[
  ['translate_17',['Translate',['../class_translate.html',1,'']]],
  ['translatedao_18',['TranslateDAO',['../class_translate_d_a_o.html',1,'']]]
];
