var searchData=
[
  ['_7etranslate_15',['~Translate',['../class_translate.html#a9b714b19a9593453c055e53a7d0c6e98',1,'Translate']]],
  ['_7etranslatedao_16',['~TranslateDAO',['../class_translate_d_a_o.html#abfccda01987f093fd9df63dd9ed1b6b0',1,'TranslateDAO']]]
];
