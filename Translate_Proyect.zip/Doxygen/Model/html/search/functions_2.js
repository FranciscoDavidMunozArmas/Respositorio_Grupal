var searchData=
[
  ['operator_3d_3d_26',['operator==',['../class_translate.html#a7988252f97930f3d11cbb432618231ee',1,'Translate::operator==(string _str)'],['../class_translate.html#a4413e656b9d37e2b7535cd5a19738518',1,'Translate::operator==(Translate _translator)']]],
  ['operator_3e_27',['operator&gt;',['../class_translate.html#a18d83e86aa674b596b9e2269f3414aab',1,'Translate::operator&gt;(string _str)'],['../class_translate.html#aa286735cc40a79b8fb96446e7bc29d73',1,'Translate::operator&gt;(Translate _translator)']]]
];
