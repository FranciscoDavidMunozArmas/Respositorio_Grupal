var searchData=
[
  ['_5fdelete_0',['_delete',['../class_translate_d_a_o.html#a2da2b650f2db27bae35dd225ae974edf',1,'TranslateDAO']]],
  ['_5fdelete_5fall_1',['_delete_all',['../class_translate_d_a_o.html#a3a32fd0cb1cf57094216d0f5782b2e44',1,'TranslateDAO']]],
  ['_5fget_2',['_get',['../class_translate_d_a_o.html#a746389ab0994b9152ba29f82c1055808',1,'TranslateDAO::_get()'],['../class_translate_d_a_o.html#a8616e70c0c38c2261ee94c3bf848fdee',1,'TranslateDAO::_get(string _str)']]],
  ['_5fpost_3',['_post',['../class_translate_d_a_o.html#a4c0b328672332ac5576a13a836adfdbc',1,'TranslateDAO']]],
  ['_5fput_4',['_put',['../class_translate_d_a_o.html#aa9fe2281ed7f3ea0f54309c76fb4772b',1,'TranslateDAO']]]
];
