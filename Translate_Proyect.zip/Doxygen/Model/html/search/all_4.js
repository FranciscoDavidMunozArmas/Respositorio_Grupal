var searchData=
[
  ['to_5fstring_12',['to_string',['../class_translate.html#a7e6d8ac0dc680ab7062f68a49891e21a',1,'Translate']]],
  ['translate_13',['Translate',['../class_translate.html',1,'Translate'],['../class_translate.html#af188c9521b09b9e3e3dd5048bfd0e53e',1,'Translate::Translate()'],['../class_translate.html#a01ed0e5d4e284f21aa66fe9c9dada003',1,'Translate::Translate(string _english, string _spanish)']]],
  ['translatedao_14',['TranslateDAO',['../class_translate_d_a_o.html',1,'TranslateDAO'],['../class_translate_d_a_o.html#aa75d209ccfdb30a7c158cae281d2c554',1,'TranslateDAO::TranslateDAO()'],['../class_translate_d_a_o.html#aa1fc5bbb194a6aafea3e0c11f5a8d9c2',1,'TranslateDAO::TranslateDAO(mongocxx::client &amp;client_, string dbName_, string collName_)']]]
];
