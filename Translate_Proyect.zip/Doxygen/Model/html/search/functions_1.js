var searchData=
[
  ['get_5fenglish_24',['get_english',['../class_translate.html#a494dee5ba3302c1d1ed29380bc08bdd2',1,'Translate']]],
  ['get_5fspanish_25',['get_spanish',['../class_translate.html#a18cba3fdcfaf84138f31119627944032',1,'Translate']]]
];
