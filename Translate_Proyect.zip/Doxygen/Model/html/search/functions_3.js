var searchData=
[
  ['set_5fenglish_28',['set_english',['../class_translate.html#a9f73af3938db427f12edcbaf759f6334',1,'Translate']]],
  ['set_5fspanish_29',['set_spanish',['../class_translate.html#a67c6e63d4a660e1545efe9fc53fd765c',1,'Translate']]]
];
