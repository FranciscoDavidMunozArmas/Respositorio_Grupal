#ifndef BANNER_H
#define BANNER_H

#include <iostream>

using namespace std;

enum class Banner_Type {
    RIGHT_LEFT, RIGHT_LEFT_RIGHT, LEFT_RIGHT
};

class Banner
{
public:
    Banner();
    void _banner_console(Banner_Type _type, string _text);
    void _banner_right_left(string _text, int x, int y);
    void _banner_right_left_left_right(string _text, int x, int y);
    void _banner_left_right(string _text, int x, int y);
    virtual ~Banner();
protected:
private:
    void _banner_console_right_left(string _text);
    void _banner_console_right_left_right(string _text);
    void _banner_console_left_right(string _text);
    void _set_console_title(string _text);
};

#endif
