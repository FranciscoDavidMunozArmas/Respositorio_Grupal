#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <tchar.h>
#include <conio.h>
#include <strsafe.h>

#include "Banner.h"
#include "Array_dinamic.cpp"
#include "Screen.cpp"

using namespace std;

Banner::Banner() {}


void Banner::_banner_right_left(string _text, int x, int y) {
	Array_dynamic _ad;
	Screen screen;
	char* _banner;
	ostringstream oss;

	_banner = (char*)malloc(_text.length() * sizeof(char));
	strcpy(_banner, _text.c_str());

	int _index = _text.length() - 1;
	for (char aux: _text) {
		screen.gotoxy(x + _index, y);
		oss << aux;
		cout << oss.str();
		_index--;
		Sleep(100);
	}

	for (int i = 0; i < _ad._dynamic_size(_banner); i++) {
		for (int j = 0; j < _ad._dynamic_size(_banner) - 1; j++) {
			*(_banner + j) = *(_banner + j + 1);
			if (j + 1 == _ad._dynamic_size(_banner) - 1 && i == 0) {
				*(_banner + j + 1) = ' ';
			}
		}
		screen.gotoxy(x, y);
		cout << _banner;
		Sleep(100);
	}
}

void Banner::_banner_right_left_left_right(string _text, int x, int y) {
	Array_dynamic _ad;
	Screen screen;
	char* _banner;
	ostringstream oss;

	_banner = (char*)malloc(_text.length() * sizeof(char));
	strcpy(_banner, _text.c_str());

	int _index = _text.length() - 1;
	for (char aux : _text) {
		screen.gotoxy(x + _index, y);
		oss << aux;
		cout << oss.str();
		_index--;
		Sleep(100);
	}

	Sleep(200);

	for (int i = 0; i < _ad._dynamic_size(_banner); i++) {
		for (int j = _ad._dynamic_size(_banner) - 1; j >= i; j--) {
			*(_banner + j) = *(_banner + j - 1);
		}
		*(_banner + i) = ' ';
		screen.gotoxy(x, y);
		cout << _banner;
		Sleep(100);
	}
}

void Banner::_banner_left_right(string _text, int x, int y) {
	Array_dynamic _ad;
	Screen screen;
	char* _banner = (char*)malloc(_text.length() * sizeof(char));
	strcpy(_banner, _text.c_str());
	ostringstream oss;

	for (int i = 0; i < _ad._dynamic_size(_banner); i++) {
		screen.gotoxy(x + i, y);
		cout << *(_banner + i);
		Sleep(100);
	}

	for (int i = 0; i < _ad._dynamic_size(_banner); i++) {
		screen.gotoxy(x + i, y);
		cout << " ";
		Sleep(100);
	}
}

void Banner::_banner_console(Banner_Type _type, string _text) {
	switch (_type)
	{
	case Banner_Type::RIGHT_LEFT:
	{
		_banner_console_right_left(_text); 
	}
		break;
	case Banner_Type::RIGHT_LEFT_RIGHT:
	{
		_banner_console_right_left_right(_text);
	}
		break;
	case Banner_Type::LEFT_RIGHT:
	{
		_banner_console_left_right(_text);
	}
		break;
	default:
		break;
	}
}

void Banner::_banner_console_right_left(string _text) {
	Array_dynamic _ad;
	Screen screen;
	char* _banner = NULL;
	string _aux;
	_banner = (char*)malloc(_text.length() * sizeof(char));
	for (int i = 0; i < _text.length(); i++) {
		_aux += " ";
	}
	strcpy(_banner, _aux.c_str());
	_set_console_title(_banner);
	Sleep(100);

	for (int i = 0; i < _text.length(); i++) {
		for (int j = 0; j < _text.length() - 1; j++) {
			*(_banner + j) = *(_banner + j + 1);
			if (j + 1 == _text.length() - 1) {
				*(_banner + j + 1) = _text.at(i);
			}
		}
		_set_console_title(_banner);
		Sleep(100);
	}
	for (int i = 0; i < _ad._dynamic_size(_banner); i++) {
		for (int j = 0; j < _ad._dynamic_size(_banner) - 1; j++) {
			*(_banner + j) = *(_banner + j + 1);
			if (j + 1 == _ad._dynamic_size(_banner) - 1 && i == 0) {
				*(_banner + j + 1) = ' ';
			}
		}
		_set_console_title(_banner);
		Sleep(100);
	}
}

void Banner::_banner_console_right_left_right(string _text) {
	Array_dynamic _ad;
	Screen screen;
	char* _banner;
	ostringstream oss;
	_banner = (char*)malloc(_text.length() * sizeof(char));
	string _aux;
	for (int i = 0; i < _text.length(); i++) {
		_aux += " ";
	}
	strcpy(_banner, _aux.c_str());

	this->_set_console_title(" ");
	for (int i = 0; i < _text.length(); i++) {
		for (int j = 0; j < _text.length() - 1; j++) {
			*(_banner + j) = *(_banner + j + 1);
			if (j + 1 == _text.length() - 1) {
				*(_banner + j + 1) = _text.at(i);
			}
		}
		_set_console_title(_banner);
		Sleep(100);
	}

	for (int i = 0; i < _text.length(); i++) {
		this->_set_console_title(_banner);
		for (int j = _text.length() - 1; j > i; j--) {
			*(_banner + j) = *(_banner + j - 1);
		}
		*(_banner + i) = 32;
		Sleep(100);
	}
}

void Banner::_banner_console_left_right(string _text) {
	Array_dynamic _ad;
	Screen screen;
	char* _banner = (char*)malloc(_text.length() * sizeof(char));
	strcpy(_banner, _text.c_str());
	ostringstream oss;
	this->_set_console_title(" ");
	for (int i = 0; i < _text.length(); i++) {
		oss << _text.at(i);
		this->_set_console_title(oss.str());
		Sleep(100);
	}

	for (int i = 0; i < _text.length(); i++) {
		this->_set_console_title(_banner);
		for (int j = _text.length() - 1; j > i ; j--) {
			*(_banner + j) = *(_banner + j - 1);
		}
		*(_banner + i) = 32;
		Sleep(100);
	}
}

void Banner::_set_console_title(string _text) {
	wstring _aux;
	_aux.assign(_text.begin(), _text.end());
	SetConsoleTitle(_aux.c_str());
}

Banner::~Banner() {}
