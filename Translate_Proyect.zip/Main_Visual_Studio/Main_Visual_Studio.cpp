/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Main
*/
#include "../Libraries_Visual_Studio/Connection.h"
#include "../Model/TranslateDAO.h"

#include <iostream>
#include <string>
#include <string.h>
#include <locale.h>
#include <windows.h>

#include "../Controller/Controller.cpp"
#include "../Controller/Controller_Parent.cpp"

using namespace std;

int main()
{
    Connection::get_instance()->createPool();
    auto _client = Connection::get_instance()->get_client_from_pool();
    TranslateDAO _dao(*_client, "Translator", "TranslatorCollection");
    setlocale(LC_CTYPE, "Spanish");
    Controller _control(_dao);
    _control.init();
}