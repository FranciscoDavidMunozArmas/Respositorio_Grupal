/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Speech_Synthesizer
*/

#ifndef SPEECH_SYNTHESIZER_H
#define SPEECH_SYNTHESIZER_H

#include <iostream>

using namespace std;

class Speech_Synthesizer
{
public:
    Speech_Synthesizer();
    void _english_speech(wstring _text);
    void _spanish_speech(wstring _text);
    virtual ~Speech_Synthesizer();
protected:
private:
};

#endif
