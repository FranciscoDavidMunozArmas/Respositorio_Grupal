/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Speech_Synthesizer
*/

#include <iostream>
#include <string>
#include <ctime>
#include <sapi.h>
#include <codecvt>
#include <locale>

#include "Speech_Synthesizer.h"

using namespace std;

/**
 * @brief Speech_Synthesizer
*/
Speech_Synthesizer::Speech_Synthesizer() {}

/**
 * @brief _english_speech
 * @param _text 
*/
void Speech_Synthesizer::_english_speech(wstring _text) {
	ISpVoice* pVoice = NULL;

	if (FAILED(::CoInitialize(NULL)))
		return;

	HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void**)&pVoice);
	if (SUCCEEDED(hr))
	{
		//pVoice->SetVoice();
		hr = pVoice->Speak((LPCWSTR)_text.c_str(), NULL, NULL);

		pVoice->Release();
		pVoice = NULL;
	}
	::CoUninitialize();
}

/**
 * @brief _spanish_speech
 * @param _text 
*/
void Speech_Synthesizer::_spanish_speech(wstring _text) {

	ISpVoice* pVoice = NULL;

	if (FAILED(::CoInitialize(NULL)))
		return;

	HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void**)&pVoice);
	if (SUCCEEDED(hr))
	{
		//pVoice->SetVoice();
		hr = pVoice->Speak((LPCWSTR)_text.c_str(), NULL, NULL);

		pVoice->Release();
		pVoice = NULL;
	}
	::CoUninitialize();
}

/**
 * @brief ~Speech_Synthesizer
*/
Speech_Synthesizer::~Speech_Synthesizer() {}
