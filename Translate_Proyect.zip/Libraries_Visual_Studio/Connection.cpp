/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Connection
*/

#include <iostream>
#include <memory>

#include <mongocxx/uri.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/pool.hpp> 

#include "Connection.h"

using namespace std;

/**
 * @brief Connection
*/
Connection::Connection() {}

Connection* Connection::_instance = NULL;

/**
 * @brief get_instance
 * @return Connection*
*/
Connection* Connection::get_instance() {
    if (_instance == NULL) {
        _instance = new Connection();
    }
    return _instance;
}

/**
 * @brief createPool
*/
void Connection::createPool() {
    if (!m_client_pool) {
        m_client_pool = (std::unique_ptr<mongocxx::pool>) new mongocxx::pool{ mongocxx::uri {} };
    }
}

/**
 * @brief get_client_from_pool
 * @return mongocxx::pool::entry
*/
mongocxx::pool::entry Connection::get_client_from_pool() {
    return m_client_pool->acquire();
}

/**
 * @brief ~Connection
*/
Connection::~Connection() {}