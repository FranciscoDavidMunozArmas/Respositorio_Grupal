/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Connection
*/

#ifndef CONNECTION_H
#define CONNECTION_H

#include <iostream>

#include <mongocxx/uri.hpp>
#include <mongocxx/instance.hpp>
#include <mongocxx/pool.hpp> 
#include <iostream>

#pragma once

class Connection {
private:
    mongocxx::instance m_dbInstance;
    std::unique_ptr<mongocxx::pool> m_client_pool;
    static Connection* _instance;
    Connection();
public:
    static Connection* get_instance();
    void createPool();
    mongocxx::pool::entry get_client_from_pool();
    virtual ~Connection();
};

#endif