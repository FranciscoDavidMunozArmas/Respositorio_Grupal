/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller_Add_Word
*/

#ifndef CONTROLLER_ADD_WORD_H
#define CONTROLLER_ADD_WORD_H

#include <iostream>

#include "Controller_Parent.h"
#include "../Model/TranslateDAO.h"

using namespace std;

class Controller_Add_Word : public Controller_Parent
{
public:
    Controller_Add_Word() : Controller_Parent() {};
    Controller_Add_Word(TranslateDAO _dao) : _dao(_dao), Controller_Parent() {};
    virtual ~Controller_Add_Word();
protected:
private:
    void _method();
    void _add_word();
    template<typename T>
    bool _is_store(T _object);
    TranslateDAO _dao;
};

#endif
