/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Controller_Translator
*/

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <codecvt>
#include <string>
#include <locale>
#include <sstream>
#include <thread>

#include "../Model/TranslateDAO.h"
#include "../Model/Translate.cpp"
#include "../Libraries/Binary_Tree.cpp"
#include "../Libraries/File_reader.h"
#include "../Libraries/Menu.cpp"
#include "../Libraries/Input.cpp"
#include "../Libraries_Visual_Studio/Speech_Synthesizer.cpp"
#include "../Libraries/PDF_Creator.cpp"
#include "../Libraries/Printer.cpp"
#include "../Libraries/lib/bitmap_image.hpp"
#include "../Libraries/Pixel.cpp"

#include "Controller_Insert_text.h"

#include "Controller_Translator.h"

#pragma once

using namespace std;

/**
 * @brief _method
*/
void Controller_Translator::_method() {
	_look_word();
}

/**
 * @brief _speak_traduction
 * @param _text
*/
void Controller_Translator::_speak_traduction(string _spanish, string _english) {
	Speech_Synthesizer _ss;
	wstring _waux;
	_waux.assign(_spanish.begin(), _spanish.end());
	_ss._english_speech(_waux);
	_waux.assign(_english.begin(), _english.end());
	_ss._english_speech(_waux);
}

/**
 * @brief _get_pdf
 * @param _pdf_name 
 * @param _text 
*/
void Controller_Translator::_get_pdf(string _pdf_name, string _text) {
	PDF_Creator _pdf(_pdf_name.c_str());
	_pdf._set_text(_text.c_str());
	_pdf._save_pdf();
}

/**
 * @brief _print_text
 * @param _text 
*/
void Controller_Translator::_print_text(string _text) {
	cout << _text << endl;
}

/**
 * @brief _printer
 * @param _path 
 * @param _text 
*/
void Controller_Translator::_printer(const char* _path, string _text) {
	File_reader _fr;
	FILE* _file = NULL;
	Printer _printer;
	_fr._write_txt_file(_path, _text);
	basic_ifstream<TCHAR> _temporal_file(_path);
	_printer.print_file(_temporal_file);
	_temporal_file.close();
	_fr._delete_all((char*)_path);
}

/**
 * @brief _look_word
*/
void Controller_Translator::_look_word() {

	Binary_Tree<Translate> _tree;
	Translate _translate;
	Controller_Insert_text _cit;

	_tree = this->_dao._get();
	string _text = _cit._get_text("Text/Texto: ");
	Translate* _t = _dao._get(_text);

	if (_t != NULL) {
		_translate = _tree._look(*_t);
		thread _speak_thread(&Controller_Translator::_speak_traduction, *this, _translate.get_english(), _translate.get_spanish());
		thread _pdf_thread(&Controller_Translator::_get_pdf, *this, "translate.pdf", _translate.to_string());
		thread _print_text_thread(&Controller_Translator::_print_text, *this, _translate.to_string());
		thread _printer_thread(&Controller_Translator::_printer, *this, "Auxiliar_file.txt", _translate.to_string());
		thread _image_thread(&Controller_Translator::_draw_word, *this, _translate.get_english());
		_print_text_thread.join();
		_speak_thread.join();
		_pdf_thread.join();
		_printer_thread.join();
		_image_thread.join();
	}
	else {
		cout << "No existe" << endl;
	}
}

/**
 * @brief _draw_word
 * @param _word 
*/
void Controller_Translator::_draw_word(string _word) {
	if (strcmp(_word.c_str(), "CAT") != 0 && strcmp(_word.c_str(), "DOG") != 0) {
		return;
	}

	ostringstream oss;
	Pixel _pixel;
	oss << _word << ".bmp";
	bitmap_image _image(oss.str().c_str());

	int _height = _image.height();
	int _width = _image.width();

	rgb_t _color;
	for (int y = 0; y < _height; y++) {
		for (int x = 0; x < _width; x++) {
			_color = _image.get_pixel(x, y);
			_pixel.draw_pixel((int)_color.red, (int)_color.green, (int)_color.blue, x, y);
		}
	}

	cin.ignore();
}

/**
 * @brief ~Controller_Translator
*/
Controller_Translator::~Controller_Translator() {}
