/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Controller_Operation
*/

#include <iostream>

#include "../Libraries/File_reader.cpp"
#include "../Libraries/Array_dinamic.h"
#include "../Libraries/Binary_Tree.cpp"

#include "../Model/TranslateDAO.h"
#include "../Model/Translate.h"

#include "Controller_Edit.cpp"
#include "Controller_Delete.cpp"

#include "Controller_Operation.h"

using namespace std;

/**
 * @brief _method
*/
void Controller_Operation::_method() {
	_menu();
}

/**
 * @brief _word_list
 * @return int
*/
int Controller_Operation::_word_list() {
	/*File_reader _fr;
	FILE* _file = NULL;*/
	Array_dynamic _ad;
	Translate* _translate = NULL;
	Binary_Tree<Translate> _tree;
	//_translate = _fr._read_file(_file, (char*)_path.c_str(), _translate);
	_tree = this->_dao._get();
	_translate = _tree._tree_to_array();
	return this->menu.options(_translate, _tree._get_element_count(), screen.YELLOW);
}

/**
 * @brief _menu
*/
void Controller_Operation::_menu() {
	Translate* _translate = NULL;
	Binary_Tree<Translate> _tree;
	_tree = this->_dao._get();
	if(_tree._is_empty()){
		return;
	}
	_translate = _tree._tree_to_array();
	if (_tree._is_empty()) {
		cout << "NO HAY DATOS" << endl;
		return;
	}
	int _option = _word_list();
	switch (_create_menu())
	{
	case 1:
	{
		Controller_Edit _ce(_dao);
		_ce._set_data(*(_translate + _option - 1));
		_ce.init();
	}
		break;
	case 2:
	{
		Controller_Delete _cd(_dao);
		_cd._set_data(*(_translate + _option - 1));
		_cd.init();
	}
		break;
	default:
		break;
	}
	cout << endl;
}

/**
 * @brief _create_menu
 * @return int
*/
int Controller_Operation::_create_menu() {
	char** option = (char**)malloc(3 * sizeof(char*));

	*(option + 0) = (char*)"EDITAR";
	*(option + 1) = (char*)"BORRAR";
	*(option + 2) = (char*)"ATRAS";

	return menu.options((char*)"QUE DESEA HACER?",option, 3, screen.YELLOW);
}

/**
 * @brief ~Controller_Operation
*/
Controller_Operation::~Controller_Operation() {}
