/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller_Delete
*/

#include <iostream>

#include "../Libraries/File_reader.cpp"

#include "../Model/TranslateDAO.h"
#include "../Model/Translate.h"

#include "Controller_Delete.h"

using namespace std;

/**
 * @brief _set_data
 * @param _data 
*/
void Controller_Delete::_set_data(Translate _data) {
	this->_data = _data;
}

/**
 * @brief _method
*/
void Controller_Delete::_method() {
	/*File_reader _fr;
	FILE* _file = NULL;
	_fr._delete(_file, (char*)_path.c_str(), this->_data);*/
	this->_dao._delete(_data);
	cout << "BORRADO CON EXITO" << endl;
}

/**
 * @brief ~Controller_Delete
*/
Controller_Delete::~Controller_Delete() {}
