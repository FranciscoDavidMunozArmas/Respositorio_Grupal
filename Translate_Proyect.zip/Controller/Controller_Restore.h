/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 28 de mayo de 2020 10:07:14
 * @function Declaration of Controller_Restore
*/

#if !defined(__Controller_Restore)
#define __Controller_Restore

#include <iostream>

#include "Controller_Parent.h"
#include "../Model/TranslateDAO.h"

using namespace std;

class Controller_Restore : public Controller_Parent
{
public:
    Controller_Restore() : Controller_Parent() {};
    Controller_Restore(TranslateDAO _dao) : _dao(_dao), Controller_Parent() {};
    void _restore();
    void _backup();
private:
    void _method();
    TranslateDAO _dao;
protected:
};

#endif
