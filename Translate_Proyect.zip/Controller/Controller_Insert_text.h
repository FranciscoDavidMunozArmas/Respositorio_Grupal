/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller_Insert_text
*/

#ifndef CONTROLLER_INSERT_TEXT_H
#define CONTROLLER_INSERT_TEXT_H

#include <iostream>

using namespace std;

class Controller_Insert_text
{
public:
    Controller_Insert_text();
    string _get_text(string _input_text);
    virtual ~Controller_Insert_text();
protected:
private:
};

#endif // CONTROLLER_INSERT_TEXT_H
