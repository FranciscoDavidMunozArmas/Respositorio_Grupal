/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller_Edit
*/

#ifndef CONTROLLER_EDIT_H
#define CONTROLLER_EDIT_H

#include <iostream>

#include "../Model/Translate.h"
#include "../Model/TranslateDAO.h"

#include "Controller_Parent.h"

using namespace std;

class Controller_Edit: public Controller_Parent
{
public:
    Controller_Edit(): Controller_Parent() {};
    Controller_Edit(TranslateDAO _dao): _dao(_dao), Controller_Parent() {};
    void _set_data(Translate _data);
    virtual ~Controller_Edit();
protected:
private:
    Translate _data;
    void _method();
    Translate _new_data();
    template<typename T>
    bool _is_store(T _object);
    TranslateDAO _dao;
};

#endif
