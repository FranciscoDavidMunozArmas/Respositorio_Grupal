/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 28 de mayo de 2020 10:07:14
 * @function Implementation of Controller
*/

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <thread>
#include <shellapi.h>

#include "Controller.h"

#include "Controller_Add_Word.cpp"
#include "Controller_Translator.cpp"
#include "Controller_Restore.CPP"
#include "Contribuitors.cpp"
#include "Controller_Operation.cpp"

#include "../Libraries/Menu.cpp"
#include "../Libraries/Screen.h"
#include "../Libraries/File_reader.cpp"
#include "../Libraries/Input.cpp"
#include "../Libraries/Array_dinamic.cpp"
#include "../Libraries/Banner.cpp"

#include "../Model/Translate.cpp"

#define HELP 59

using namespace std;

/**
 * @brief _method
*/
void Controller::_method() {
	thread _banner(&Controller::_banner, *this);
	thread _help(&Controller::_help, *this);
	thread _main_program(&Controller::_main_program, *this);
	_main_program.join();
	_banner.join();
	_help.join();
}

/**
 * @brief _banner
*/
void Controller::_banner() {
	Banner _banner_c;
	do {
		_banner_c._banner_console(Banner_Type::RIGHT_LEFT, "PROYECTO TRADUCTOR");
	} while (true);
}

/**
 * @brief _main_program
*/
void Controller::_main_program() {
	do {
		fflush(stdout);
		screen.hide_cursor();
		_selection_menu();
		system("cls");
		fflush(stdout);
	} while (true);
}

/**
 * @brief _help
*/
void Controller::_help() {
	do {
		if (_kbhit()) {
			if (_getch() == HELP) {
				HINSTANCE status;
				status = ShellExecute(NULL,TEXT("open"), TEXT("HelpFile.chm"), NULL, NULL, SW_SHOWDEFAULT);
			}
		}
	} while (true);
}

/**
 * @brief _selection_menu
 * @param flag
*/
void Controller::_selection_menu()
{
	switch (_set_menu()) {
	case 1: {
		Controller_Add_Word _caw(_dao);
		_caw.init();
	}break;
	case 2:{
		Controller_Translator _ct(_dao);
		_ct.init();
	}break;
	case 3: {
		Controller_Operation _co(_dao);
		_co.init();
	}break;
	case 4: {
		Controller_Restore _cr(_dao);
		_cr._backup();
	}break;
	case 5: {
		Controller_Restore _cr(_dao);
		_cr._restore();
	}break;
	case 6: {
		Contribuitors _contribuitors;
		_contribuitors.init();
	}break;
	case 7: {
		cout << endl << endl;
		exit(0);
	}break;
	}
	system("pause");
}

/**
 * @brief _set_menu
 * @return int
*/
int Controller::_set_menu() {
	char** option = (char**)malloc(7 * sizeof(char*));

	*(option + 0) = (char*)"INGRESAR PALABRA";
	*(option + 1) = (char*)"TRADUCIR";
	*(option + 2) = (char*)"EDITAR/BORRAR";
	*(option + 3) = (char*)"COPIA DE SEGURIDAD";
	*(option + 4) = (char*)"RESTAURAR";
	*(option + 5) = (char*)"CONTRIBUIDORES";
	*(option + 6) = (char*)"SALIR";

	return menu.options(option, 7, screen.YELLOW);
}