/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 28 de mayo de 2020 10:07:14
 * @function Implementation of Controller_Restore
*/

#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#include "Controller_Restore.h"
#include "../Libraries/File_reader.cpp"
#include "../Libraries/Date.cpp"

using namespace std;

/**
 * @brief _method
*/
void Controller_Restore::_method() {
}

/**
 * @brief _backup
*/
void Controller_Restore::_backup() {
	FILE* _file;
	File_reader _fr;
	Date _date;
	ostringstream oss;
	_fr._write_txt_file((char*)"../back_up.txt", _date.create_key());
	_fr._add_line((char*)"../back_up.txt");
	system("cls");
	oss << "C:\\mongodump.exe --db Translator -o dump/" << _date.create_key();
	system(oss.str().c_str());
}

/**
 * @brief _restore
*/
void Controller_Restore::_restore() {
	FILE* _file;
	File_reader _fr;
	Array_dynamic _ad;
	ostringstream oss;
	char** _data = NULL;
	int _size;
	//Development of the function
	system("cls");
	_data = _fr._read_txt_file((char*)"../back_up.txt", _data);
	_size = _ad._dynamic_size(_data) - 1;
	strcpy(*(_data + _ad._dynamic_size(_data) - 1), "ATRAS");
	int _index = menu.options((char*)"QUE ARCHIVO DESEA RESTAURAR: ", _data, _size + 1);
	//Restore Data
	if (_index - 1 < _size) {
		system("cls");
		_dao._delete_all();
		oss << "C:\\mongorestore.exe --db Translator dump/" << *(_data + _index - 1) << "/Translator";
		system(oss.str().c_str());
	}
}