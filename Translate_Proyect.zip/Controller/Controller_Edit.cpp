/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Controller_Edit
*/

#include <iostream>

#include "../Libraries/File_reader.cpp"
#include "../Libraries/Input.cpp"

#include "../Model/Translate.h"
#include "../Model/TranslateDAO.h"

#include "Controller_Insert_text.cpp"
#include "Controller_Edit.h"

using namespace std;

/**
 * @brief _set_data
 * @param _data 
*/
void Controller_Edit::_set_data(Translate _data) {
	this->_data = _data;
}

/**
 * @brief _method
*/
void Controller_Edit::_method() {
	/*File_reader _fr;
	FILE* _file = NULL;*/
	Translate _translate = _new_data();
	//_fr._update(_file, (char*)_path.c_str(), &_data, &_translate);
	_dao._put(_data, _translate);
	cout << "EDITADO CON EXITO" << endl;
}

/**
 * @brief _new_data
 * @return Translate
*/
Translate Controller_Edit::_new_data() {
	system("cls");
	Input _input;
	Controller_Insert_text _cit;
	Translate _translate;
	do {
		string _english = _cit._get_text("Text: ");
		string _spanish = _cit._get_text("Texto: ");
		_translate.set_english(_strupr((char*)_english.c_str()));
		_translate.set_spanish(_strupr((char*)_spanish.c_str()));
	} while (_is_store(_translate));
	return _translate;
}

/**
 * @brief _is_store
 * @tparam T 
 * @param _object 
 * @return bool
*/
template<typename T>
bool Controller_Edit::_is_store(T _object) {
	/*File_reader _fr;
	FILE* _file = NULL;*/
	Translate _translate;
	Binary_Tree<Translate> _tree;
	//_tree = _fr._read_file_tree(_file, (char*)_path.c_str(), &_translate);
	_tree = this->_dao._get();
	_translate = _tree._look(_object);
	if (_translate == _object) {
		return true;
	}
	else {
		return false;
	}
}

/**
 * @brief ~Controller_Edit
*/
Controller_Edit::~Controller_Edit() {}
