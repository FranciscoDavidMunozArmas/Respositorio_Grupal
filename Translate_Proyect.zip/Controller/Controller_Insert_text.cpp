/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Controller_Translator
*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>

#include "../Libraries/Input.cpp"
#include "../Libraries/Verify_number.h"

#include "Controller_Insert_text.h"

#pragma once

using namespace std;

/**
 * @brief Controller_Insert_text
 * @return 
*/
Controller_Insert_text::Controller_Insert_text() {}

/**
 * @brief _get_text
 * @param _input_text 
 * @return string
*/
string Controller_Insert_text::_get_text(string _input_text) {
	Input _input;
	string _text;
	do {
		system("cls");
		_text = _input.input(_input_text);
	} while (!is_alpha(_text) || _text.length() >= 30);
	return strupr((char*)_text.c_str());
}

/**
 * @brief ~Controller_Insert_text
*/
Controller_Insert_text::~Controller_Insert_text() {}
