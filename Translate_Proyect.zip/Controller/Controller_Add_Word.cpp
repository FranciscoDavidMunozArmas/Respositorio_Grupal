/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Implementation of Controller_Add_Word
*/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>

#include "../Model/TranslateDAO.h"
#include "../Model/Translate.cpp"
#include "../Libraries/Input.cpp"
#include "../Libraries/File_reader.cpp"
#include "../Libraries/Binary_Tree.cpp"

#include "Controller_Insert_text.cpp"

#include "Controller_Add_Word.h"

#pragma once

using namespace std;

/**
 * @brief _method
*/
void Controller_Add_Word::_method() {
	_add_word();
}

/**
 * @brief _add_word
*/
void Controller_Add_Word::_add_word() {
	system("cls");
	Input _input;
	//File_reader _fr;
	Controller_Insert_text _cit;
	string _english = _cit._get_text("Text: ");
	string _spanish = _cit._get_text("Texto: ");
	Translate _translate(strupr((char*)_english.c_str()), strupr((char*)_spanish.c_str()));
	if (!_is_store(_translate)) {
		this->_dao._post(_translate);
		/*FILE* _file = NULL;
		_fr._write_in_file(_file, (char*)_path.c_str(), &_translate);*/
	}
	else {
		cout << "Ya esta registrada / Is already store" << endl;
		system("Pause");
	}
	
}

/**
 * @brief _is_store
 * @tparam T 
 * @param _object 
 * @return bool
*/
template<typename T>
bool Controller_Add_Word::_is_store(T _object) {
	/*File_reader _fr;
	FILE* _file = NULL;*/
	Translate _translate;
	Binary_Tree<Translate> _tree;
	//_tree = _fr._read_file_tree(_file, (char*)_path.c_str(), &_translate);
	_tree = this->_dao._get();
	_translate = _tree._look(_object);
	if (_translate == _object) {
		return true;
	}
	else {
		return false;
	}

}

/**
 * @brief ~Controller_Add_Word
*/
Controller_Add_Word::~Controller_Add_Word() {}
