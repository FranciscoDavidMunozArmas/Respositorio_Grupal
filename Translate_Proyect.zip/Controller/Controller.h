/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller
*/

#if !defined(__Controller)
#define __Controller

#include <iostream>

#include "Controller_Parent.h"
#include "../Model/TranslateDAO.h"

using namespace std;

class Controller: public Controller_Parent
{
public:
    Controller() : Controller_Parent() {};
    Controller(TranslateDAO _dao) : _dao(_dao), Controller_Parent() {};
private:
    void _method();
    void _selection_menu();
    int _set_menu();
    void _banner();
    void _main_program();
    void _help();
    TranslateDAO _dao;
protected:
};

#endif
