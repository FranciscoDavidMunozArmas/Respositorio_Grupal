/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller_Operation
*/

#ifndef CONTROLLER_OPERATION_H
#define CONTROLLER_OPERATION_H

#include <iostream>

#include "../Model/Translate.h"
#include "../Model/TranslateDAO.h"

#include "Controller_Parent.h"

using namespace std;

class Controller_Operation: public Controller_Parent
{
public:
    Controller_Operation(): Controller_Parent() {};
    Controller_Operation(TranslateDAO _dao): _dao(_dao), Controller_Parent() {};
    virtual ~Controller_Operation();
protected:
private:
    void _method();
    int _word_list();
    void _menu();
    int _create_menu();
    TranslateDAO _dao;
};

#endif
