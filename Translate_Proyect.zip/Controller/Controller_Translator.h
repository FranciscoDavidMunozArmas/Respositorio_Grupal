/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 25 de agosto de 2020 10:07:14
 * @function Declaration of Controller_Translator
*/

#ifndef CONTROLLER_TRANSLATOR_H
#define CONTROLLER_TRANSLATOR_H

#include <iostream>

#include "Controller_Parent.h"
#include "../Model/TranslateDAO.h"

using namespace std;

class Controller_Translator : public Controller_Parent
{
public:
    Controller_Translator() : Controller_Parent() {};
    Controller_Translator(TranslateDAO _dao) : _dao(_dao), Controller_Parent() {};
    virtual ~Controller_Translator();
protected:
private:
    TranslateDAO _dao;
    void _method();
    void _look_word();
    void _speak_traduction(string _spanish, string _english);
    void _draw_word(string _word);
    void _get_pdf(string _pdf_name, string _text);
    void _print_text(string _text);
    void _printer(const char* _path, string _text);
};

#endif
