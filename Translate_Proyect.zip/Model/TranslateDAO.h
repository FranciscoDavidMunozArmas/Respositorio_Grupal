/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date lunes, 6 de septiembre de 2020 15:04:32
 * @function Declaration of TranslateDAO
*/

#ifndef TRANSLATEDAO_H
#define TRANSLATEDAO_H

#include <iostream>

#include <mongocxx/database.hpp>
#include <mongocxx/pool.hpp>
#include <mongocxx/client.hpp>
#include <mongocxx/exception/bulk_write_exception.hpp>

#include <bsoncxx/json.hpp>
#include <bsoncxx/exception/exception.hpp>

#include "Translate.h"
#include "../Libraries/Binary_Tree.h"

#pragma once

using namespace std;

class TranslateDAO {
public:
    TranslateDAO();
    TranslateDAO(mongocxx::client& client_, string dbName_, string collName_);
    void _post(Translate _translate);
    Binary_Tree<Translate> _get();
    Translate* _get(string _str);
    void _put(Translate _data_for_change, Translate _new_data);
    void _delete(Translate _translate);
    void _delete_all();
    virtual ~TranslateDAO();
private:
    std::string m_dbName;
    std::string m_collectionName;
    mongocxx::database m_db;
    mongocxx::collection m_collection;
    string _english;
    string _spanish;
};

#endif