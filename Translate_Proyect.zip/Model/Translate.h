/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date lunes, 17 de agosto de 2020 15:04:32
 * @function Declaration of Translate
*/

#if !defined(__Traductor_Translate_h)
#define __Traductor_Translate_h

#include <iostream>

using namespace std;

class Translate
{
public:
	Translate();
	//Translate(string _english, string _spanish);
	Translate(string _english, string _spanish);
	string get_english();
	void set_english(string _english);
	string get_spanish();
	void set_spanish(string _spanish);
	/*string get_english();
	void set_english(string _english);
	string get_spanish();
	void set_spanish(string _spanish);*/
	string to_string();
	bool operator > (string _str);
	bool operator == (string _str);
	bool operator > (Translate _translator);
	bool operator == (Translate _translator);
	friend ostream& operator << (ostream& o, Translate p);
	~Translate();
protected:
private:
    char _english[30];
    char _spanish[30];
   /*string _english;
   string _spanish;*/
};

#endif
