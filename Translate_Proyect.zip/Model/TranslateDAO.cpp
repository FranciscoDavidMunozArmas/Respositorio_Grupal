/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date lunes, 6 de septiembre de 2020 15:04:32
 * @function Implementation of TranslateDAO
*/

#include <iostream>
#include <string>

#include "../Libraries_Visual_Studio/Connection.h"

#include <mongocxx/database.hpp>
#include <mongocxx/pool.hpp>
#include <mongocxx/client.hpp>

#include <bsoncxx/json.hpp>
#include <bsoncxx/builder/stream/document.hpp>
#include <bsoncxx/exception/exception.hpp>

#include "TranslateDAO.h"
#include "Translate.h"

#pragma once

using namespace std;
using namespace mongocxx;

/**
 * @brief TranslateDAO
*/
TranslateDAO::TranslateDAO() {}

/**
 * @brief TranslateDAO
 * @param client_ 
 * @param dbName_ 
 * @param collName_ 
*/
TranslateDAO::TranslateDAO(mongocxx::client& client_, string dbName_, string collName_): m_dbName(dbName_), m_collectionName(collName_){
	m_collection = client_[dbName_][collName_];
	_english = "english";
	_spanish = "spanish";
}

/**
 * @brief _get
 * @return Binary_Tree<Translate>
*/
Binary_Tree<Translate> TranslateDAO::_get() {
	mongocxx::cursor cursor = m_collection.find({});
	Binary_Tree<Translate> _tree;
	for (auto&& doc : cursor) {
		Translate _tl(doc[_english].get_utf8().value.to_string(), doc[_spanish].get_utf8().value.to_string());
		_tree._add(_tl);
	}
	return _tree;
}

/**
 * @brief _get
 * @param _str 
 * @return Translate*
*/
Translate* TranslateDAO::_get(string _str) {
	mongocxx::cursor cursor = m_collection.find({});
	Translate* _aux = NULL;
	for (auto&& doc : cursor) {
		if (strcmp(doc[_english].get_utf8().value.to_string().c_str(), _str.c_str()) == 0 || strcmp(doc[_spanish].get_utf8().value.to_string().c_str(), _str.c_str()) == 0) {
			_aux = new Translate(doc[_english].get_utf8().value.to_string(), doc[_spanish].get_utf8().value.to_string().c_str());
		}
	}
	return _aux;
}

/**
 * @brief _put
 * @param _data_for_change 
 * @param _new_data 
*/
void TranslateDAO::_put(Translate _data_for_change, Translate _new_data) {
	auto document = m_collection.find({});
	bsoncxx::builder::stream::document query{};
	query << _english << _data_for_change.get_english()
		<< _spanish << _data_for_change.get_spanish();
	bsoncxx::builder::stream::document update{};
	update << _english << _new_data.get_english()
		<< _spanish << _new_data.get_spanish();
	auto save = m_collection.find_one_and_update(query.view(), update.view());
}

/**
 * @brief _post
 * @param _translate 
*/
void TranslateDAO::_post(Translate _translate) {
	auto builder = bsoncxx::builder::stream::document{};
	bsoncxx::document::value doc_value = builder
		<< _english << _translate.get_english()
		<< _spanish << _translate.get_spanish()
		<< bsoncxx::builder::stream::finalize;
	auto result = m_collection.insert_one(move(doc_value));
}

/**
 * @brief _delete
 * @param _translate 
*/
void TranslateDAO::_delete(Translate _translate) {
	auto document = m_collection.find({});
	bsoncxx::builder::stream::document delete_doc{};
	delete_doc << _english << _translate.get_english()
		<< _spanish << _translate.get_spanish();
	auto save = m_collection.find_one_and_delete(delete_doc.view());
}

/**
 * @brief _delete_all
*/
void TranslateDAO::_delete_all() {
	m_collection.drop();
}

/**
 * @brief ~TranslateDAO
*/
TranslateDAO::~TranslateDAO(){}