/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date lunes, 17 de agosto de 2020 15:04:32
 * @function Implementation of Translate
*/

#include <iostream>
#include <sstream>
#include <string>

#include "Translate.h"

#pragma once

using namespace std;

/**
 * @brief Translate
 * @return
*/
Translate::Translate() {
	strcpy(this->_english, "");
	strcpy(this->_spanish, "");
}

/**
 * @brief Translate
 * @param _english
 * @param _spanish
 * @return
*/
Translate::Translate(string _english, string _spanish)
{
	strcpy(this->_english, _english.c_str());
	strcpy(this->_spanish, _spanish.c_str());
}

/**
 * @brief get_english
 * @return string
*/
string Translate::get_english() {
	return this->_english;
}

/**
 * @brief set_english
 * @param _english 
*/
void Translate::set_english(string _english) {
	strcpy(this->_english, _english.c_str());
}

/**
 * @brief get_spanish
 * @return string
*/
string Translate::get_spanish() {
	return this->_spanish;
}

/**
 * @brief set_spanish
 * @param _spanish 
*/
void Translate::set_spanish(string _spanish) {
	strcpy(this->_spanish, _spanish.c_str());
}

/**
 * @brief >
 * @param _str 
 * @return bool
*/
bool Translate::operator > (string _str) {
	return (strcmp(_str.c_str(), (const char*)this->_spanish) == -1 || strcmp(_str.c_str(),(const char*)this->_english) == -1);
}

/**
 * @brief ==
 * @param _str 
 * @return bool
*/
bool Translate::operator == (string _str) {
	cout << this->get_english() << this->get_spanish() << endl;
	cout << _str << endl;
	return (strcmp((const char*)this->_spanish, _str.c_str()) == 0 || strcmp((const char*)this->_english, _str.c_str()) == 0);
}

/**
 * @brief >
 * @param _translator 
 * @return 
*/
bool Translate::operator > (Translate _translator) {
	return (strcmp(_translator.get_spanish().c_str(), (const char*)this->_spanish) == -1 || strcmp(_translator.get_english().c_str(), (const char*)this->_english) == -1);
}

/**
 * @brief 
 * @param _translator 
 * @return 
*/
bool Translate::operator == (Translate _translator) {
	return (strcmp((const char*)this->_spanish, _translator.get_spanish().c_str()) == 0 || strcmp((const char*)this->_english, _translator.get_english().c_str()) == 0);
}

/**
 * @brief <<
 * @param o 
 * @param p 
 * @return ostream&
*/
ostream& operator << (ostream& o, Translate p) {
	o << p.to_string();
	return o;
}

/**
 * @brief to_string
 * @return string
*/
string Translate::to_string() {
	ostringstream oss;
	oss << "English: " << this->_english << " -> Espa�ol: " << this->_spanish << endl;
	return oss.str();
}

/**
 * @brief ~Translate
 * @return
*/
Translate::~Translate() {}
