/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date viernes, 21 de agosto de 2020 10:07:14
 * @function Main
*/

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <SFML/Graphics.hpp>

#include "../Tree_Graphics.cpp"

#include "../Binary_Tree.cpp"
#include "../Libraries/Menu.cpp"
#include "../Libraries/Input.cpp"
#include "../Libraries/To_number.cpp"
#include "../Verify_Prime.cpp"

using namespace std;

int option();
template<typename T>
void menu(Binary_Tree<T>* _stack);

/**
 * @brief option
 * @return int
*/
int option() {
    Menu _menu;
    char** _option = (char**)calloc(8, sizeof(char*));
    *(_option + 0) = (char*)"Introducir";
    *(_option + 1) = (char*)"Borrar";
    *(_option + 2) = (char*)"Buscar";
    *(_option + 3) = (char*)"Nivel";
    *(_option + 4) = (char*)"Nivel por dato";
    *(_option + 5) = (char*)"Primo";
    *(_option + 6) = (char*)"Imprimir";
    *(_option + 7) = (char*)"Salir";

    return _menu.options("Seleccione una opcion", _option, 8);
}

/**
 * @brief menu
 * @tparam T
 * @param _tree
*/
template<typename T>
void menu(Binary_Tree<T>* _tree) {
    Input _input;
    char _answer;
    int i;

    switch (option()) {
    case 1:
        do {
            system("cls");
            i = to_int(_input.input_int_number("Ingrese un numero: "));
            _tree->_add(i);
            fflush(stdin);
            cout << "Quiere continuar? (S/N): ";
            scanf("%c", &_answer);
            fflush(stdin);
        } while (tolower(_answer) != 'n');
        break;
    case 2:
    {
        system("cls");
        if (!_tree->_is_empty()) {
            i = to_int(_input.input_int_number("Ingrese un numero: "));
            _tree->_delete(i);
        }
        else {
            cout << "Arbol Vacio" << endl;
        }
    }
    break;
    case 3:
    {
        system("cls");
        int* _aux;
        if (!_tree->_is_empty()) {
            i = to_int(_input.input_int_number("Ingrese un numero: "));
            _aux = _tree->_look(i);
            if (_aux == NULL) {
                cout << "No existe" << endl;
            }
            else {
                cout << "Dato recuperado: " << (int)_aux << endl;
            }
        }
        else {
            cout << "Arbol Vacio" << endl;
        }
    }
    break;
    case 4:
    {
        system("cls");
        if (!_tree->_is_empty()) {
            cout << "Nivel/Profundidad/Altura: " << _tree->level() << endl;
        }
        else {
            cout << "Arbol Vacio" << endl;
        }
    }break;
    case 5:
    {
        system("cls");
        int _aux;
        if (!_tree->_is_empty()) {
            i = to_int(_input.input_int_number("Ingrese un numero: "));
            _aux = _tree->level(i);
            if (_aux == -1) {
                cout << "No existe" << endl;
            }
            else {
                cout << "Nivel: " << _aux << endl;
            }
        }
        else {
            cout << "Arbol Vacio" << endl;
        }
    }
    break;
    case 6:
    {
        system("cls");
        int _aux;
        if (!_tree->_is_empty()) {
            Verify_Prime _vp;
            _vp.set_node(_tree->_get_root());
            cout << "Numeros primos: " << _vp.verify_node_prime() << endl;
        }
        else {
            cout << "Arbol Vacio" << endl;
        }
    }
    break;
    case 7: 
    {
        system("cls");
        _tree->print();
        Tree_Graphics<T> tg;
        tg._print_tree(_tree);
        cout << endl;
    }
        break;
    default:
        cout << endl << endl << endl << endl;
        exit(0);
        break;
    }
    system("pause");
    system("cls");
}

int main()
{
    Binary_Tree<int> _tree;
    while (true) {
        menu(&_tree);
    }
}